/**
 * Coin shop: buying and equipping cosmetics.
 *
 * Spending coins is a read-check-write on one balance, so the whole purchase
 * runs in a single transaction that first locks the player's progress row
 * (`FOR UPDATE`). Two simultaneous requests therefore queue up instead of both
 * seeing the same balance. The `coins >= 0` CHECK on the column and the
 * UNIQUE(user_id, item_id) constraint are the backstops behind that lock.
 */

import {
  getShopItem,
  type ShopCategory,
  type ShopState,
} from '@cb/shared';
import { query, queryOne, withTransaction } from '../../db/pool.js';
import { errors } from '../../lib/errors.js';
import { logger } from '../../lib/logger.js';

export async function shopState(userId: string): Promise<ShopState> {
  const progress = await queryOne<{
    coins: string;
    level: number;
    equipped_title: string | null;
    equipped_theme: string | null;
  }>('SELECT coins, level, equipped_title, equipped_theme FROM player_progress WHERE user_id = $1', [
    userId,
  ]);
  if (!progress) throw errors.notFound('Player not found.');

  const owned = await query<{ item_id: string }>(
    'SELECT item_id FROM shop_purchases WHERE user_id = $1',
    [userId],
  );

  return {
    coins: progress.coins,
    level: progress.level,
    owned: owned.map((row) => row.item_id),
    equippedTitle: progress.equipped_title,
    equippedTheme: progress.equipped_theme,
  };
}

export async function buyItem(userId: string, itemId: string): Promise<ShopState> {
  const item = getShopItem(itemId);
  if (!item) throw errors.notFound('That item does not exist.');

  await withTransaction(async (tx) => {
    const { rows } = await tx.query<{ coins: string; level: number }>(
      'SELECT coins, level FROM player_progress WHERE user_id = $1 FOR UPDATE',
      [userId],
    );
    const progress = rows[0];
    if (!progress) throw errors.notFound('Player not found.');

    if (progress.level < item.minLevel) {
      throw errors.forbidden(`${item.name} unlocks at level ${item.minLevel}.`);
    }

    const already = await tx.query(
      'SELECT 1 FROM shop_purchases WHERE user_id = $1 AND item_id = $2',
      [userId, item.id],
    );
    if (already.rowCount && already.rowCount > 0) {
      throw errors.invalidState('You already own this item.');
    }

    const coins = BigInt(progress.coins);
    if (coins < BigInt(item.priceCoins)) throw errors.insufficientCoins(item.priceCoins, coins);

    await tx.query('UPDATE player_progress SET coins = coins - $2, updated_at = now() WHERE user_id = $1', [
      userId,
      item.priceCoins,
    ]);
    await tx.query(
      'INSERT INTO shop_purchases (user_id, item_id, price_coins) VALUES ($1, $2, $3)',
      [userId, item.id, item.priceCoins],
    );
  });

  logger.info({ userId, itemId: item.id, price: item.priceCoins }, 'shop purchase');
  return shopState(userId);
}

/** Equip an owned item, or pass `itemId = null` to go back to the default. */
export async function equip(
  userId: string,
  category: ShopCategory,
  itemId: string | null,
): Promise<ShopState> {
  if (itemId !== null) {
    const item = getShopItem(itemId);
    if (!item || item.category !== category) throw errors.validation('That item does not fit here.');

    const owned = await queryOne('SELECT 1 FROM shop_purchases WHERE user_id = $1 AND item_id = $2', [
      userId,
      itemId,
    ]);
    if (!owned) throw errors.forbidden('You do not own this item.');
  }

  const column = category === 'TITLE' ? 'equipped_title' : 'equipped_theme';
  await query(`UPDATE player_progress SET ${column} = $2, updated_at = now() WHERE user_id = $1`, [
    userId,
    itemId,
  ]);
  return shopState(userId);
}
