/**
 * Shop purchases against the real database (see coins.integration.test.ts for
 * why the "is there a database" check lives inside each test).
 */

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { closePool, pool, query, withTransaction } from '../db/pool.js';
import { runMigrations } from '../db/migrate.js';
import { buyItem, equip, shopState } from '../modules/shop/service.js';

let dbAvailable = false;
let seq = 0;

async function makeUser(opts: { coins: number; level?: number }): Promise<string> {
  const telegramId = (9_000_000_000n + BigInt(++seq) + BigInt(Date.now() % 1_000_000)).toString();
  return withTransaction(async (tx) => {
    const { rows } = await tx.query<{ id: string }>(
      `INSERT INTO users (telegram_id, first_name) VALUES ($1, 'ShopTest') RETURNING id`,
      [telegramId],
    );
    const id = rows[0]!.id;
    await tx.query('INSERT INTO wallets (user_id) VALUES ($1)', [id]);
    await tx.query('INSERT INTO player_progress (user_id, coins, level) VALUES ($1, $2, $3)', [
      id,
      opts.coins,
      opts.level ?? 1,
    ]);
    return id;
  });
}

async function coinsOf(userId: string): Promise<number> {
  const rows = await query<{ coins: string }>('SELECT coins FROM player_progress WHERE user_id = $1', [userId]);
  return Number(rows[0]?.coins ?? 0);
}

beforeAll(async () => {
  try {
    await pool.query('SELECT 1');
    await runMigrations();
    dbAvailable = true;
  } catch {
    dbAvailable = false;
  }
}, 30_000);

afterAll(async () => {
  if (dbAvailable) await closePool().catch(() => undefined);
});

describe('shop', () => {
  it('charges the catalogue price and records the purchase', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 500 });
    const state = await buyItem(user, 'title_ghost'); // 150
    expect(await coinsOf(user)).toBe(350);
    expect(state.owned).toContain('title_ghost');
    expect(state.coins).toBe('350');
  });

  it('refuses a purchase the player cannot afford, and charges nothing', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 100 });
    await expect(buyItem(user, 'title_ghost')).rejects.toThrow(/coins/i);
    expect(await coinsOf(user)).toBe(100);
    expect((await shopState(user)).owned).toEqual([]);
  });

  it('refuses an item above the player level', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 5000, level: 1 });
    await expect(buyItem(user, 'title_king')).rejects.toThrow(/unlocks at level/i);
    expect(await coinsOf(user)).toBe(5000);
  });

  it('refuses to sell the same item twice', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 1000 });
    await buyItem(user, 'theme_fire'); // 250
    await expect(buyItem(user, 'theme_fire')).rejects.toThrow(/already own/i);
    expect(await coinsOf(user)).toBe(750);
  });

  it('two simultaneous purchases of one item charge once', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 1000 });
    const results = await Promise.allSettled([buyItem(user, 'theme_ice'), buyItem(user, 'theme_ice')]);
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    expect(await coinsOf(user)).toBe(750);
  });

  it('simultaneous purchases can never overspend the balance', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 300 }); // enough for ONE 250 item, not two
    const results = await Promise.allSettled([buyItem(user, 'theme_fire'), buyItem(user, 'theme_ice')]);
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    expect(await coinsOf(user)).toBe(50);
  });

  it('only lets you equip what you own, in the right slot', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 1000 });
    await expect(equip(user, 'TITLE', 'title_ghost')).rejects.toThrow(/do not own/i);
    await buyItem(user, 'title_ghost');
    await expect(equip(user, 'TAP_THEME', 'title_ghost')).rejects.toThrow(/does not fit/i);

    const equipped = await equip(user, 'TITLE', 'title_ghost');
    expect(equipped.equippedTitle).toBe('title_ghost');
    const cleared = await equip(user, 'TITLE', null);
    expect(cleared.equippedTitle).toBeNull();
  });

  it('rejects unknown items', async () => {
    if (!dbAvailable) return;
    const user = await makeUser({ coins: 1000 });
    await expect(buyItem(user, 'free_money')).rejects.toThrow(/does not exist/i);
  });
});
