/**
 * Coin settlement against the real database.
 *
 * Like the ledger suite this needs Postgres; each test quietly returns when no
 * database is reachable so `npm test` still works without one. (The check runs
 * inside the tests, not in `describe.skipIf`, because skipIf is evaluated
 * before beforeAll has had a chance to connect.)
 */

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { closePool, pool, query, withTransaction } from '../db/pool.js';
import { runMigrations } from '../db/migrate.js';
import { settleMatch } from '../modules/game/settlement.js';
import { createMatch } from '../modules/game/store.js';

let dbAvailable = false;
let seq = 0;

async function makeUser(): Promise<string> {
  const telegramId = (8_000_000_000n + BigInt(++seq) + BigInt(Date.now() % 1_000_000)).toString();
  return withTransaction(async (tx) => {
    const { rows } = await tx.query<{ id: string }>(
      `INSERT INTO users (telegram_id, first_name) VALUES ($1, 'CoinTest') RETURNING id`,
      [telegramId],
    );
    const id = rows[0]!.id;
    await tx.query('INSERT INTO wallets (user_id) VALUES ($1)', [id]);
    await tx.query('INSERT INTO player_progress (user_id) VALUES ($1)', [id]);
    return id;
  });
}

async function coinsOf(userId: string): Promise<bigint> {
  const rows = await query<{ coins: string }>('SELECT coins FROM player_progress WHERE user_id = $1', [userId]);
  return BigInt(rows[0]?.coins ?? '0');
}

async function playFreeMatch(opts: {
  winnerId: string;
  loserOrAi: string | null;
  style?: 'CLASSIC' | 'MARATHON';
  roundsToWin: number;
  maxRounds: number;
}): Promise<{ winnerCoins: bigint }> {
  const ai = opts.loserOrAi === null;
  const matchId = await withTransaction((tx) =>
    createMatch(tx, {
      mode: 'FREE',
      entryMicros: 0n,
      commissionBps: 0,
      commissionMicros: 0n,
      prizeMicros: 0n,
      roundsToWin: opts.roundsToWin,
      maxRounds: opts.maxRounds,
      isAiMatch: ai,
      players: [
        { slot: 1, userId: opts.winnerId, isAi: false, displayName: 'W', avatarUrl: null, level: 1 },
        { slot: 2, userId: opts.loserOrAi, isAi: ai, displayName: 'L', avatarUrl: null, level: 1 },
      ],
    }),
  );

  await settleMatch({
    matchId,
    mode: 'FREE',
    style: opts.style,
    entryMicros: 0n,
    commissionBps: 0,
    championSlot: 1,
    players: [
      { slot: 1, userId: opts.winnerId, isAi: false, roundsWon: opts.roundsToWin },
      { slot: 2, userId: opts.loserOrAi, isAi: ai, roundsWon: 0 },
    ],
  });
  return { winnerCoins: await coinsOf(opts.winnerId) };
}

beforeAll(async () => {
  try {
    await pool.query('SELECT 1');
    await runMigrations();
    dbAvailable = true;
  } catch {
    dbAvailable = false;
  }
}, 30_000);

afterAll(async () => {
  if (dbAvailable) await closePool().catch(() => undefined);
});

describe('coins', () => {
  it('pays coins to the winner of a free match against a human, nothing to the loser', async () => {
    if (!dbAvailable) return;
    const winner = await makeUser();
    const loser = await makeUser();

    const { winnerCoins } = await playFreeMatch({ winnerId: winner, loserOrAi: loser, roundsToWin: 3, maxRounds: 5 });

    expect(winnerCoins).toBeGreaterThan(0n);
    expect(await coinsOf(loser)).toBe(0n);
  });

  it('pays double in Marathon', async () => {
    if (!dbAvailable) return;
    const classicWinner = await makeUser();
    const marathonWinner = await makeUser();

    const classic = await playFreeMatch({
      winnerId: classicWinner, loserOrAi: await makeUser(), style: 'CLASSIC', roundsToWin: 3, maxRounds: 5,
    });
    const marathon = await playFreeMatch({
      winnerId: marathonWinner, loserOrAi: await makeUser(), style: 'MARATHON', roundsToWin: 4, maxRounds: 7,
    });

    // Same first-win points, so the difference is exactly the multiplier
    // (any level-up bonus would be identical for both brand-new accounts).
    expect(marathon.winnerCoins).toBeGreaterThan(classic.winnerCoins);
  });

  it('pays no coins for beating the AI', async () => {
    if (!dbAvailable) return;
    const winner = await makeUser();
    const { winnerCoins } = await playFreeMatch({ winnerId: winner, loserOrAi: null, roundsToWin: 3, maxRounds: 5 });
    expect(winnerCoins).toBe(0n);
  });

  it('settling the same match twice pays coins once', async () => {
    if (!dbAvailable) return;
    const winner = await makeUser();
    const loser = await makeUser();
    const matchId = await withTransaction((tx) =>
      createMatch(tx, {
        mode: 'FREE', entryMicros: 0n, commissionBps: 0, commissionMicros: 0n, prizeMicros: 0n,
        roundsToWin: 3, maxRounds: 5, isAiMatch: false,
        players: [
          { slot: 1, userId: winner, isAi: false, displayName: 'W', avatarUrl: null, level: 1 },
          { slot: 2, userId: loser, isAi: false, displayName: 'L', avatarUrl: null, level: 1 },
        ],
      }),
    );
    const input = {
      matchId, mode: 'FREE' as const, entryMicros: 0n, commissionBps: 0, championSlot: 1 as const,
      players: [
        { slot: 1 as const, userId: winner, isAi: false, roundsWon: 3 },
        { slot: 2 as const, userId: loser, isAi: false, roundsWon: 0 },
      ],
    };
    await settleMatch(input);
    const once = await coinsOf(winner);
    await settleMatch(input);
    await settleMatch(input);
    expect(await coinsOf(winner)).toBe(once);
  });
});
