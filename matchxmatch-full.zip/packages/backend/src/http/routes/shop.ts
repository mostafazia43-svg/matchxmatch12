/** Coin shop routes. Everything here is cosmetic; no route touches a match. */

import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { errors } from '../../lib/errors.js';
import { buyItem, equip, shopState } from '../../modules/shop/service.js';
import { ok, rateLimit, requireAuth, requireOperational } from '../plugins.js';

const buySchema = z.object({ itemId: z.string().min(1).max(64) });
const equipSchema = z.object({
  category: z.enum(['TITLE', 'TAP_THEME']),
  itemId: z.string().min(1).max(64).nullable(),
});

export async function shopRoutes(app: FastifyInstance): Promise<void> {
  app.get('/api/shop', async (request) => {
    const user = await requireAuth(request);
    return ok(await shopState(user.id));
  });

  app.post(
    '/api/shop/buy',
    { preHandler: rateLimit({ limit: 20, windowMs: 60_000, scope: 'shop' }) },
    async (request) => {
      const user = await requireAuth(request);
      await requireOperational(request);
      const body = buySchema.safeParse(request.body);
      if (!body.success) throw errors.validation('itemId is required.');
      return ok(await buyItem(user.id, body.data.itemId));
    },
  );

  app.post(
    '/api/shop/equip',
    { preHandler: rateLimit({ limit: 40, windowMs: 60_000, scope: 'shop' }) },
    async (request) => {
      const user = await requireAuth(request);
      const body = equipSchema.safeParse(request.body);
      if (!body.success) throw errors.validation('category and itemId are required.');
      return ok(await equip(user.id, body.data.category, body.data.itemId));
    },
  );
}
