/**
 * Game styles, player titles and coin rewards.
 *
 * A style only changes HOW MANY rounds a match lasts. Timing, anti-cheat and
 * the winner decision are identical in every style, so unlocking a style never
 * gives anyone a speed advantage - it only makes the duel longer and the
 * rewards bigger. Styles are free/demo only; paid matches are always CLASSIC.
 */

import type { GameMode } from './types.js';

export type GameStyle = 'CLASSIC' | 'SPRINT' | 'MARATHON' | 'ENDURANCE';

export interface GameStyleDef {
  id: GameStyle;
  label: string;
  blurb: string;
  /** Player level needed to queue for this style. */
  minLevel: number;
  /** null = use the admin-configured value (the Classic default). */
  roundsToWin: number | null;
  maxRounds: number | null;
  /** Multiplies the coins a win pays. */
  coinMultiplier: number;
}

export const GAME_STYLES: readonly GameStyleDef[] = [
  {
    id: 'CLASSIC',
    label: 'Classic',
    blurb: 'The standard duel.',
    minLevel: 1,
    roundsToWin: null,
    maxRounds: null,
    coinMultiplier: 1,
  },
  {
    id: 'SPRINT',
    label: 'Sprint',
    blurb: 'Quick duel - first to 2 of 3 rounds.',
    minLevel: 2,
    roundsToWin: 2,
    maxRounds: 3,
    coinMultiplier: 1,
  },
  {
    id: 'MARATHON',
    label: 'Marathon',
    blurb: 'Long duel - first to 4 of 7 rounds. Coins x2.',
    minLevel: 4,
    roundsToWin: 4,
    maxRounds: 7,
    coinMultiplier: 2,
  },
  {
    id: 'ENDURANCE',
    label: 'Endurance',
    blurb: 'The ultimate test - first to 5 of 9 rounds. Coins x3.',
    minLevel: 8,
    roundsToWin: 5,
    maxRounds: 9,
    coinMultiplier: 3,
  },
];

export const DEFAULT_GAME_STYLE: GameStyle = 'CLASSIC';

export function isGameStyle(value: unknown): value is GameStyle {
  return GAME_STYLES.some((style) => style.id === value);
}

export function getGameStyle(id: GameStyle | null | undefined): GameStyleDef {
  return GAME_STYLES.find((style) => style.id === id) ?? GAME_STYLES[0]!;
}

export function isStyleUnlocked(id: GameStyle, level: number): boolean {
  return level >= getGameStyle(id).minLevel;
}

/** Paid matches ignore the requested style. */
export function effectiveStyle(mode: GameMode, requested: GameStyle | null | undefined): GameStyle {
  return mode === 'PAID' ? DEFAULT_GAME_STYLE : getGameStyle(requested).id;
}

export function styleRounds(
  id: GameStyle,
  configured: { roundsToWin: number; maxRounds: number },
): { roundsToWin: number; maxRounds: number } {
  const style = getGameStyle(id);
  return {
    roundsToWin: style.roundsToWin ?? configured.roundsToWin,
    maxRounds: style.maxRounds ?? configured.maxRounds,
  };
}

// ---------------------------------------------------------------- titles

const TITLES: readonly { minLevel: number; title: string }[] = [
  { minLevel: 1, title: 'Rookie' },
  { minLevel: 3, title: 'Quick Finger' },
  { minLevel: 6, title: 'Sharpshooter' },
  { minLevel: 10, title: 'Lightning' },
  { minLevel: 15, title: 'Speed Demon' },
  { minLevel: 25, title: 'Champion' },
  { minLevel: 40, title: 'Legend' },
];

export function titleForLevel(level: number): string {
  let current = TITLES[0]!.title;
  for (const entry of TITLES) {
    if (level >= entry.minLevel) current = entry.title;
  }
  return current;
}

// ---------------------------------------------------------------- coins

/** Flat coin bonus for every level gained in a match. */
export const COIN_LEVEL_UP_BONUS = 50;

export interface CoinInput {
  mode: GameMode;
  style: GameStyle;
  /** Ranking points this match paid (already includes the streak bonus). */
  pointsGained: bigint;
  levelsGained: number;
  /** Both players were real people. Matches against the AI pay no coins. */
  vsHuman: boolean;
}

/**
 * Coins earned by one player for one match.
 *
 * Coins are a spendable balance separate from ranking points. They are paid
 * only for matches against another human, so the AI cannot be farmed.
 */
export function computeCoins(input: CoinInput): bigint {
  if (input.mode === 'DEMO' || !input.vsHuman) return 0n;
  const base = input.pointsGained > 0n
    ? input.pointsGained * BigInt(getGameStyle(input.style).coinMultiplier)
    : 0n;
  const bonus = BigInt(Math.max(0, input.levelsGained)) * BigInt(COIN_LEVEL_UP_BONUS);
  return base + bonus;
}
