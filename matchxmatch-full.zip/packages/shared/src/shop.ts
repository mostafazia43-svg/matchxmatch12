/**
 * The coin shop catalogue.
 *
 * The catalogue lives here, in shared code, so the Mini App renders exactly
 * the prices the server charges. The server never trusts a price from the
 * client: it looks the item up by id in this list and charges what it says.
 *
 * Everything sold today is cosmetic. Nothing here changes timing, scoring or
 * who wins a round.
 */

import { titleForLevel } from './styles.js';

export type ShopCategory = 'TITLE' | 'TAP_THEME';

export interface ShopItem {
  id: string;
  category: ShopCategory;
  name: string;
  description: string;
  priceCoins: number;
  /** Player level needed before the item can be bought. */
  minLevel: number;
  /** TITLE: the text shown. TAP_THEME: the theme key used by the CSS. */
  value: string;
}

export const SHOP_ITEMS: readonly ShopItem[] = [
  // ---- titles (shown instead of your level title)
  { id: 'title_ghost', category: 'TITLE', name: 'Ghost', description: 'Silent. Quick. Gone.', priceCoins: 150, minLevel: 1, value: 'Ghost' },
  { id: 'title_night_owl', category: 'TITLE', name: 'Night Owl', description: 'Sharpest when everyone sleeps.', priceCoins: 300, minLevel: 3, value: 'Night Owl' },
  { id: 'title_sniper', category: 'TITLE', name: 'Sniper', description: 'One tap. One round.', priceCoins: 600, minLevel: 6, value: 'Sniper' },
  { id: 'title_king', category: 'TITLE', name: 'King of Clicks', description: 'For players who rule the button.', priceCoins: 2000, minLevel: 15, value: 'King of Clicks' },

  // ---- tap button colours
  { id: 'theme_fire', category: 'TAP_THEME', name: 'Fire button', description: 'A blazing orange GO button.', priceCoins: 250, minLevel: 1, value: 'fire' },
  { id: 'theme_ice', category: 'TAP_THEME', name: 'Ice button', description: 'A cool blue GO button.', priceCoins: 250, minLevel: 1, value: 'ice' },
  { id: 'theme_violet', category: 'TAP_THEME', name: 'Violet button', description: 'A glowing violet GO button.', priceCoins: 400, minLevel: 4, value: 'violet' },
  { id: 'theme_gold', category: 'TAP_THEME', name: 'Gold button', description: 'A golden GO button for veterans.', priceCoins: 1000, minLevel: 10, value: 'gold' },
];

export function getShopItem(id: string): ShopItem | null {
  return SHOP_ITEMS.find((item) => item.id === id) ?? null;
}

export function itemsInCategory(category: ShopCategory): ShopItem[] {
  return SHOP_ITEMS.filter((item) => item.category === category);
}

/**
 * The title to show next to a player: the one they bought and equipped, or the
 * free level title. An equipped id that is not a known TITLE (removed from the
 * catalogue, or corrupt) quietly falls back to the level title.
 */
export function displayTitle(level: number, equippedTitleId: string | null | undefined): string {
  const item = equippedTitleId ? getShopItem(equippedTitleId) : null;
  return item && item.category === 'TITLE' ? item.value : titleForLevel(level);
}

/** CSS theme key for an equipped TAP_THEME item id, or null for the default. */
export function tapThemeKey(equippedThemeId: string | null | undefined): string | null {
  const item = equippedThemeId ? getShopItem(equippedThemeId) : null;
  return item && item.category === 'TAP_THEME' ? item.value : null;
}

// ---------------------------------------------------------------- API shapes

export interface ShopState {
  coins: string;
  level: number;
  /** Item ids the player owns. */
  owned: string[];
  equippedTitle: string | null;
  equippedTheme: string | null;
}
