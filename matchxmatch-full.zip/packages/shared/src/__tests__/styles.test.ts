import { describe, expect, it } from 'vitest';
import {
  COIN_LEVEL_UP_BONUS,
  computeCoins,
  effectiveStyle,
  isStyleUnlocked,
  styleRounds,
  titleForLevel,
} from '../styles.js';

describe('game styles', () => {
  const configured = { roundsToWin: 3, maxRounds: 5 };

  it('classic follows the admin settings, others are fixed', () => {
    expect(styleRounds('CLASSIC', configured)).toEqual({ roundsToWin: 3, maxRounds: 5 });
    expect(styleRounds('SPRINT', configured)).toEqual({ roundsToWin: 2, maxRounds: 3 });
    expect(styleRounds('MARATHON', configured)).toEqual({ roundsToWin: 4, maxRounds: 7 });
    expect(styleRounds('ENDURANCE', configured)).toEqual({ roundsToWin: 5, maxRounds: 9 });
  });

  it('every style can always produce a champion', () => {
    for (const style of ['SPRINT', 'MARATHON', 'ENDURANCE'] as const) {
      const { roundsToWin, maxRounds } = styleRounds(style, configured);
      expect(maxRounds).toBe(roundsToWin * 2 - 1);
    }
  });

  it('unlocks by level', () => {
    expect(isStyleUnlocked('CLASSIC', 1)).toBe(true);
    expect(isStyleUnlocked('SPRINT', 1)).toBe(false);
    expect(isStyleUnlocked('SPRINT', 2)).toBe(true);
    expect(isStyleUnlocked('MARATHON', 3)).toBe(false);
    expect(isStyleUnlocked('MARATHON', 4)).toBe(true);
    expect(isStyleUnlocked('ENDURANCE', 7)).toBe(false);
    expect(isStyleUnlocked('ENDURANCE', 8)).toBe(true);
  });

  it('paid matches always play classic', () => {
    expect(effectiveStyle('PAID', 'ENDURANCE')).toBe('CLASSIC');
    expect(effectiveStyle('FREE', 'ENDURANCE')).toBe('ENDURANCE');
    expect(effectiveStyle('FREE', undefined)).toBe('CLASSIC');
  });
});

describe('titles', () => {
  it('follow the level thresholds', () => {
    expect(titleForLevel(1)).toBe('Rookie');
    expect(titleForLevel(2)).toBe('Rookie');
    expect(titleForLevel(3)).toBe('Quick Finger');
    expect(titleForLevel(10)).toBe('Lightning');
    expect(titleForLevel(200)).toBe('Legend');
  });
});

describe('coins', () => {
  const base = { mode: 'FREE' as const, style: 'CLASSIC' as const, vsHuman: true, levelsGained: 0 };

  it('pays the ranking points as coins, scaled by style', () => {
    expect(computeCoins({ ...base, pointsGained: 10n })).toBe(10n);
    expect(computeCoins({ ...base, style: 'MARATHON', pointsGained: 10n })).toBe(20n);
    expect(computeCoins({ ...base, style: 'ENDURANCE', pointsGained: 15n })).toBe(45n);
  });

  it('pays a flat bonus per level gained', () => {
    expect(computeCoins({ ...base, pointsGained: 0n, levelsGained: 1 })).toBe(
      BigInt(COIN_LEVEL_UP_BONUS),
    );
    expect(computeCoins({ ...base, pointsGained: 10n, levelsGained: 2 })).toBe(
      10n + BigInt(COIN_LEVEL_UP_BONUS * 2),
    );
  });

  it('pays nothing for demo or AI matches', () => {
    expect(computeCoins({ ...base, mode: 'DEMO', pointsGained: 10n })).toBe(0n);
    expect(computeCoins({ ...base, vsHuman: false, pointsGained: 10n, levelsGained: 1 })).toBe(0n);
  });

  it('never goes negative', () => {
    expect(computeCoins({ ...base, pointsGained: -5n, levelsGained: -1 })).toBe(0n);
  });
});
