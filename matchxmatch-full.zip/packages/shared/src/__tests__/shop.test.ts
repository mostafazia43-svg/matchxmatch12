import { describe, expect, it } from 'vitest';
import { SHOP_ITEMS, displayTitle, getShopItem, tapThemeKey } from '../shop.js';

describe('shop catalogue', () => {
  it('has unique ids and sane prices', () => {
    const ids = SHOP_ITEMS.map((item) => item.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const item of SHOP_ITEMS) {
      expect(Number.isInteger(item.priceCoins)).toBe(true);
      expect(item.priceCoins).toBeGreaterThan(0);
      expect(item.minLevel).toBeGreaterThanOrEqual(1);
    }
  });

  it('every theme item maps to a theme key the CSS knows', () => {
    const known = new Set(['fire', 'ice', 'violet', 'gold']);
    for (const item of SHOP_ITEMS.filter((i) => i.category === 'TAP_THEME')) {
      expect(known.has(item.value)).toBe(true);
    }
  });

  it('shows the equipped title, else the level title', () => {
    expect(displayTitle(1, null)).toBe('Rookie');
    expect(displayTitle(1, 'title_ghost')).toBe('Ghost');
    expect(displayTitle(10, 'title_does_not_exist')).toBe('Lightning');
    // a theme id can never be shown as a title
    expect(displayTitle(1, 'theme_fire')).toBe('Rookie');
  });

  it('resolves theme keys safely', () => {
    expect(tapThemeKey(null)).toBeNull();
    expect(tapThemeKey('theme_fire')).toBe('fire');
    expect(tapThemeKey('title_ghost')).toBeNull();
    expect(tapThemeKey('nope')).toBeNull();
    expect(getShopItem('theme_gold')?.priceCoins).toBe(1000);
  });
});
