/**
 * Coin shop. Everything here is cosmetic - nothing changes timing or who wins.
 * Prices come from the shared catalogue; the server re-checks every purchase.
 */

import { useCallback, useEffect, useState } from 'react';
import { SHOP_ITEMS, type ShopCategory, type ShopItem, type ShopState } from '@cb/shared';
import { Banner, Card, Pill } from '../components/ui.js';
import { api, ApiError } from '../lib/api.js';
import { haptic } from '../lib/telegram.js';
import { useStore } from '../state/store.js';

const SECTIONS: { category: ShopCategory; title: string; hint: string }[] = [
  { category: 'TITLE', title: 'Titles', hint: 'Shown next to your name instead of your level title.' },
  { category: 'TAP_THEME', title: 'Button colours', hint: 'Recolours the GO button in your matches.' },
];

export function ShopScreen(): JSX.Element {
  const { refresh, toast } = useStore();
  const [state, setState] = useState<ShopState | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  const load = useCallback(async () => {
    try {
      setState(await api.get<ShopState>('/api/shop'));
      setFailed(false);
    } catch {
      setFailed(true);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const act = useCallback(
    async (key: string, run: () => Promise<ShopState>, success: string) => {
      setBusy(key);
      try {
        setState(await run());
        haptic.success();
        toast(success, 'success');
        void refresh();
      } catch (error) {
        haptic.error();
        toast(error instanceof ApiError ? error.message : 'Something went wrong.', 'error');
      } finally {
        setBusy(null);
      }
    },
    [refresh, toast],
  );

  if (failed) {
    return (
      <div className="screen stack">
        <Banner tone="error">Could not load the shop.</Banner>
        <button type="button" className="btn btn--block" onClick={() => void load()}>
          Try again
        </button>
      </div>
    );
  }

  if (!state) {
    return (
      <div className="screen">
        <div className="empty">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      </div>
    );
  }

  const coins = BigInt(state.coins);

  const renderItem = (item: ShopItem): JSX.Element => {
    const owned = state.owned.includes(item.id);
    const equipped =
      item.category === 'TITLE' ? state.equippedTitle === item.id : state.equippedTheme === item.id;
    const levelLocked = state.level < item.minLevel;
    const cantAfford = !owned && !levelLocked && coins < BigInt(item.priceCoins);

    return (
      <Card key={item.id}>
        <div className="row row--between" style={{ gap: 10 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="row" style={{ gap: 6 }}>
              <strong>{item.name}</strong>
              {equipped ? <Pill tone="accent">Equipped</Pill> : null}
            </div>
            <div className="small dim" style={{ marginTop: 2 }}>
              {item.description}
            </div>
            {levelLocked ? (
              <div className="tiny faint" style={{ marginTop: 4 }}>
                🔒 Unlocks at level {item.minLevel}
              </div>
            ) : null}
          </div>

          {owned ? (
            <button
              type="button"
              className="btn btn--sm"
              disabled={busy !== null}
              onClick={() =>
                void act(
                  item.id,
                  () =>
                    api.post<ShopState>('/api/shop/equip', {
                      category: item.category,
                      itemId: equipped ? null : item.id,
                    }),
                  equipped ? 'Back to the default.' : `${item.name} equipped.`,
                )
              }
            >
              {equipped ? 'Unequip' : 'Equip'}
            </button>
          ) : (
            <button
              type="button"
              className="btn btn--sm btn--primary"
              disabled={busy !== null || levelLocked || cantAfford}
              onClick={() =>
                void act(
                  item.id,
                  () => api.post<ShopState>('/api/shop/buy', { itemId: item.id }),
                  `${item.name} bought!`,
                )
              }
            >
              🪙 {item.priceCoins}
            </button>
          )}
        </div>
      </Card>
    );
  };

  return (
    <div className="screen stack" style={{ gap: 16 }}>
      <div className="row row--between">
        <h1>Shop</h1>
        <Pill tone="accent">🪙 {state.coins}</Pill>
      </div>

      <div className="small dim">
        Earn coins by winning matches against real players. Everything here is cosmetic and never
        changes who wins.
      </div>

      {SECTIONS.map((section) => (
        <div key={section.category} className="stack" style={{ gap: 8 }}>
          <div>
            <div className="section-title" style={{ margin: 0 }}>
              {section.title}
            </div>
            <div className="tiny faint">{section.hint}</div>
          </div>
          {SHOP_ITEMS.filter((item) => item.category === section.category).map(renderItem)}
        </div>
      ))}
    </div>
  );
}
